import { Link, useSearchParams } from 'react-router-dom'

export default function SignIn() {
  const [searchParams] = useSearchParams()
  const redirect = searchParams.get('redirect') || '/'

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 bg-pigmatch-cream">
      <Link to="/" className="absolute top-6 left-6 font-display font-bold text-pigmatch-earth hover:opacity-80">
        ← PigMatch
      </Link>
      <div className="w-full max-w-sm">
        <h1 className="font-display font-bold text-2xl text-pigmatch-earth text-center mb-2">
          Sign in
        </h1>
        <p className="text-pigmatch-earth/70 text-center mb-8 text-sm">
          Choose how you want to use PigMatch
        </p>
        <div className="space-y-4">
          <Link
            to={`/hunter/signin?redirect=${encodeURIComponent(redirect)}`}
            className="block w-full py-4 px-6 rounded-xl bg-pigmatch-forest hover:bg-pigmatch-forest/90 text-pigmatch-cream font-semibold text-center transition"
          >
            I&apos;m a Hunter
          </Link>
          <Link
            to={`/landowner/signin?redirect=${encodeURIComponent(redirect)}`}
            className="block w-full py-4 px-6 rounded-xl bg-pigmatch-bark hover:bg-pigmatch-bark/90 text-pigmatch-cream font-semibold text-center transition"
          >
            I&apos;m a Landowner
          </Link>
        </div>
      </div>
    </div>
  )
}
