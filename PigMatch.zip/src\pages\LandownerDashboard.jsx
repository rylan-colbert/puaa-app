import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function LandownerDashboard() {
  const { user, signOut } = useAuth()
  const navigate = useNavigate()

  const handleSignOut = () => {
    signOut()
    navigate('/')
  }

  return (
    <div className="min-h-screen bg-pigmatch-cream">
      <header className="bg-pigmatch-bark text-pigmatch-cream px-6 py-4 flex items-center justify-between">
        <Link to="/landowner/dashboard" className="font-display font-bold text-lg">PigMatch</Link>
        <div className="flex items-center gap-4">
          <span className="text-sm text-pigmatch-cream/80">{user?.email}</span>
          <button onClick={handleSignOut} className="text-sm hover:underline">Sign out</button>
        </div>
      </header>
      <main className="max-w-6xl mx-auto p-8">
        <h1 className="font-display font-bold text-2xl text-pigmatch-earth mb-2">Landowner Dashboard</h1>
        <p className="text-pigmatch-earth/70 mb-6">Property and sighting form coming next.</p>
        <div className="h-64 rounded-xl bg-pigmatch-sage/20 border border-pigmatch-bark/20 flex items-center justify-center text-pigmatch-earth/60">
          Form placeholder
        </div>
      </main>
    </div>
  )
}
